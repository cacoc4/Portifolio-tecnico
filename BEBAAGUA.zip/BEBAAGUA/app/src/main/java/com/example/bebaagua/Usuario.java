package com.example.bebaagua;

public class Usuario {
    String login,senha;
    int perfil;

    public Usuario(String login, String senha, int perfil) {
        this.login = login;
        this.senha = senha;
        this.perfil = perfil;
    }
}
