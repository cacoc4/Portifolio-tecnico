class Main {
  public static void main(String[] args) {
    Animal animal;
    Habitat habitat;

    animal = new Animal("Alligatoridae", "jacaré do papo amarelo", "Chordata", "Crocodylia", "ALLIGATOR", "Reptilia");
    habitat = new Habitat(animal, "Pantanal");
    
    System.out.println("deu certo!");
  }
}