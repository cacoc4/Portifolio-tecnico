package com.example.bebaagua;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;

public class TelaAdm extends AppCompatActivity {
EditText login, senha;
CheckBox Adm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_adm);
        login = findViewById(R.id.nuLogin);
        senha = findViewById(R.id.nuSenha);
        Adm = findViewById(R.id.cb);


    }
    public void criarUsuario(){
        String l = login.getText().toString();
        String s = senha.getText().toString();
        if(Adm.isChecked()){
            Usuario u = new Usuario(l,s, 2);
        }
        else{
            Usuario u = new Usuario(l,s, 1);
        }
    }
}