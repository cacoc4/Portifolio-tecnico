public class Habitat{
  private Animal animal;
  private Fauna fauna;
  private Flora flora;
  private String tipo;

  public Habitat(Animal animal, String tipo){
    this.animal = animal;
    this.tipo = tipo;
  }
  public void criarFauna(String especie){
    fauna = new Fauna(especie);
  }
  public void criarFlora(String planta){
    flora = new Flora();
  } 
}