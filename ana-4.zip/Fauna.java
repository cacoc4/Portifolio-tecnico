public class Fauna{
  private Animal animal;
  private String especie;

    public Fauna(String especie){
      this.especie = especie;
    }
  public void criarAnimal(){
    animal = new
      Animal("Alligatoridae", "jacaré do papo amarelo", "Chordata", "Crocodylia", "ALLIGATOR", "Reptilia");
  }
}