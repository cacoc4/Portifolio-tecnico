package com.example.geometrialegal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton rat, rab, rav, rn, rf, rv, rh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        rat = findViewById(R.id.RBAreaTotal);
        rab = findViewById(R.id.RBAreaDaBasePelaAreaTotal);
        rav = findViewById(R.id.RBAreaDaBasePeloVolume);
        rn = findViewById(R.id.RBNumeroDeLados);
        rf = findViewById(R.id.RBAreaDasFaces);
        rv = findViewById(R.id.RBVolume);
        rh = findViewById(R.id.RBAltura);
    }
         public void BTProsseguir(View abacate){
            Intent i = new Intent(this, TelaConta.class);
            if(rat.isChecked()){//formula da area total At = 2*Ab + N*F
                TelaConta.conta = 1;
                startActivity(i);
            }
            else if(rab.isChecked()){//formula da area da base pela area total Ab = At - (2*Ab + N*F)
                TelaConta.conta = 2;
                startActivity(i);
            }
             else if(rav.isChecked()){//formula da area da base pelo volume Ab = V/H
                TelaConta.conta = 3;
                startActivity(i);
            }
             else if(rn.isChecked()){//formula do numero de faces N = (At - 2*Ab) / F
                TelaConta.conta = 4;
                startActivity(i);
            }
            else if(rf.isChecked()){//formula da area das faces F = (At - 2*Ab) / N
                TelaConta.conta = 5;
                startActivity(i);
            }
             else if(rv.isChecked()) {//formula do volume V = Ab*H
                TelaConta.conta = 6;
                startActivity(i);
            }
             else if(rh.isChecked()){//formula da altura H = V/Ab
                TelaConta.conta = 7  ;
                startActivity(i);
             }
            else{
                //Nenhum foi selecionado
                Toast.makeText(this, "Nenhuma opção selecionada!", Toast.LENGTH_SHORT).show();
            }

    }
}