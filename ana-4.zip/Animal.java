public class Animal{
  private String familia, especie, filo, ordem, genero, classe;


  public Animal(String familia,String especie,String filo,String ordem,String genero,String classe){
    this.familia = familia;
    this.especie = especie;
    this.filo = filo;
    this.genero = genero;
    this.classe = classe;
}
  public void comer(){
    
  }

}