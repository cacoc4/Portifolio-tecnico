public class Flora{
  private String planta;

  public Flora(){
    
  }

  public void criarPlanta(String planta){
    
  }
}