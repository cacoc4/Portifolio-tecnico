public class Pessoa{
  private String nome;
  private int idade;
  private String cpf;
  private double peso;
  private double altura;
  private Mascara mascara;

  public Pessoa(String nome, String cpf){
    this.nome = nome;
    this.cpf = cpf;

  }
}