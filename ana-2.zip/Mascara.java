public class Mascara{
  private String cor, modelo, tamanho, material;
  private boolean comMascara;

  public Mascara(String cor, String modelo){
      this.cor = cor;
      this.modelo = modelo;
  }

  public boolean colocarMarcara(Mascara mascara, boolean comMascara){
    return comMascara;
  }
}