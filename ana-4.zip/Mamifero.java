public class Mamifero extends Animal{
  private int amamentacao;
  private int gestacao;

  public Mamifero(String familia,String especie,String filo,String ordem,String genero,String classe){
    super(familia, especie, filo, ordem, genero, classe);
  }
}